/*
Author: Mark Irwin
Date: 9/24/2024
Version: 1.1

Description: This code Represents a text based adventure within the Android Studio environment in
Java. The core of the game revolves around a player utilizing the movement buttons to explore
a damage space station, collecting items from each room, then finally finding the escape pod to
escape to safety if all items were found successfully.

GamePlayActivity represents logic for creation, room movement, inventory management, end of
game states, and button logic.

Enhancement: Converted the code from python to Java within Android Studio.Removed the ability for
users to manually input directions via text, now the player can utilize directional buttons for
movement. Also implemented a collect item button to allow the player to collect an item without
having to type yes. Also made it usable on the mobile environment. Finally I also introduced a main
menu, game environment, leaderboard, and exit game functionality.

*/

package com.example.capstone_spaceship_escape_mark_irwin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.HashMap;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;


public class GamePlayActivity extends AppCompatActivity{

    // Creates hash map that will store room information.
    HashMap<String, HashMap<String, String>> rooms = new HashMap<>();

    // Creates an array list that will be utilized for the player inventory.
    ArrayList<String> inventory = new ArrayList<>();

    // Sets starting room to the Observatory.
    String current_room = "Observatory";


    // ENHANCEMENT: When the start game button is pushed on the main menu will load the start of
    // the game. This ensures all buttons are enabled or disabled by default for the purpose of
    // functionality.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Sets current view to game play activity.
        setContentView(R.layout.gameplay_loop);

        // Sets the game text to the game text field within the game play activity.
        TextView gameText = findViewById(R.id.game_text);

        // Sets up the puppy image with the ImageView.
        ImageView puppy = findViewById(R.id.puppy_image);
        // When game starts ensures the puppy image is not visible.
        puppy.setVisibility(View.GONE);

        // Sets the introduction and rules messages as the default on creation.
        gameText.setText("\t\t\t\t\t\t\t\t\t\tSPACESHIP ESCAPE!!!\n" +
                "\nYou are a star traveler and you have awoken to your ships alarms going off!" +
                " Meteors are coming and your engine has been disabled from a smaller meteor, " +
                " you immediately realize the seriousness of your situation and know survival " +
                "is all that matters now. \n\nMake your way through your ship, " +
                "enter what ever rooms you can that have not been damaged and collect survival items.\n" +
                "\nOnce you have collected all seven survival items find your way to the escape pod.\n" +
                "\nYou need to collect seven items to be able to survive the trip in the escape pod. \n\n" +
                "*Remember though, you need all SEVEN items to survive and win. " +
                "Forcing the escape pod to launch without all seven items will end the game as survival would not be possible.*" +
                "\n\n\t\t\t\t\t\t\tPlease press START to start the game!");

        // Activates and reacts to the activation start game button.
        Button startButton = findViewById(R.id.start_button);
        // Sets start button to be enabled by default.
        startButton.setEnabled(true);

        // Activates and reacts to the activation end game button.
        Button endGameButton = findViewById(R.id.end_game_button);
        // Sets end game button to be enabled by default.
        endGameButton.setEnabled(true);

        // Sets the login button to be disabled as long as the game has not been started.
        Button inventoryButton = findViewById(R.id.view_inventory_button);
        // Sets Inventory button to be disabled by default.
        inventoryButton.setEnabled(false);

        // Sets the collect item button to be disabled as long as the game has not been started.
        Button collectItemButton = findViewById(R.id.collect_item_button);
        // Sets Collect Item button to be disabled by default.
        collectItemButton.setEnabled(false);

        // Sets the north button to be disabled as long as the game has not been started.
        Button northButton = findViewById(R.id.north_button);
        // Sets north button to be disabled by default.
        northButton.setEnabled(false);

        // Sets the south button to be disabled as long as the game has not been started.
        Button southButton = findViewById(R.id.south_button);
        // Sets south button to be disabled by default.
        southButton.setEnabled(false);

        // Sets the east button to be disabled as long as the game has not been started.
        Button eastButton = findViewById(R.id.east_button);
        // Sets east button to be disabled by default.
        eastButton.setEnabled(false);

        // Sets the west button to be disabled as long as the game has not been started.
        Button westButton = findViewById(R.id.west_button);
        // Sets west button to be disabled by default.
        westButton.setEnabled(false);

        // If end game button is pressed returns the player back to the main menu.
        endGameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Return to the Main Menu.
                Intent intent = new Intent(GamePlayActivity.this, MainActivity.class);
                // Ensures that the main menu activity will always be closed when pressing the exit game button.
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });

        // Acknowledges you understand the rules of the game and starts the game.
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Confirms the user has read the games instructions and is ready to play.
                startGame();
            }
        });

        // Opens the inventory information tab.
        inventoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Shows the player how many items are currently in their inventory.
                inventoryInformation();
            }
        });

        // Attempts to collect an item in the current room.
        collectItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Attempts to collect an item from the current room and adds it to the players inventory.
                collectItem();
            }
        });

        // Checks to see if the player pressed the north button.
        northButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Moves the player in the direction of north.
                travel("North");
            }
        });

        // Checks to see if the player pressed the south button.
        southButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Moves the player in the direction of south.
                travel("South");
            }
        });

        // Checks to see if the player pressed the east button.
        eastButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Moves the player in the direction of east.
                travel("East");
            }
        });

        // Checks to see if the player pressed the west button.
        westButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Moves the player in the direction of west.
                travel("West");
            }
        });


    }

        // Starts the game play loop triggering all buttons to enable except start and allows player movements.
        public void startGame() {

            // Activates and reacts to the activation start game button.
            Button startButton = findViewById(R.id.start_button);
            // Sets start button to be disabled.
            startButton.setEnabled(false);

            // Activates and reacts to the activation end game button.
            Button endGameButton = findViewById(R.id.end_game_button);
            // Sets end game button to be enabled.
            endGameButton.setEnabled(true);

            // Sets the login button to be enabled.
            Button inventoryButton = findViewById(R.id.view_inventory_button);
            // Sets Inventory button to be enabled.
            inventoryButton.setEnabled(true);

            // Sets the collect item button to be enabled.
            Button collectItemButton = findViewById(R.id.collect_item_button);
            // Sets Collect Item button to be enabled.
            collectItemButton.setEnabled(true);

            // Sets the north button to be enabled.
            Button northButton = findViewById(R.id.north_button);
            // Sets north button to be enabled.
            northButton.setEnabled(true);

            // Sets the south button to be enabled.
            Button southButton = findViewById(R.id.south_button);
            // Sets south button to be enabled.
            southButton.setEnabled(true);

            // Sets the east button to be enabled.
            Button eastButton = findViewById(R.id.east_button);
            // Sets east button to be enabled.
            eastButton.setEnabled(true);

            // Sets the west button to be enabled.
            Button westButton = findViewById(R.id.west_button);
            // Sets west button to be enabled.
            westButton.setEnabled(true);

            // Sets the game text to the game text field within the game play activity.
            TextView gameText = findViewById(R.id.game_text);

            // Sets game text to current situation within the game.
            gameText.setText("You have awoken in the Observatory! No items of importance appear to be in this room, " +
                    "Choose which direction you would like to travel towards. \n\n\n" + "You have awoken in the observatory, the last thing you remember is viewing the stars." +
                    "Your head is foggy and the room is a mess, smoke is filling the room. You look around\n" +
                    "and see a couple of doors, the West door looks intact and is the direction of your personal room.\n\n\n\n" +
                    "_____________________________________________________________\n" +
                    "| Goal: Find all SEVEN survival items and LAUNCH the               | Escape Pod!\n" +
                    "| Controls: \n| -Inventory: Displays your current Inventory Progress \n| -Player Movement: North, South, East, West \n|" +
                    " -Item Collection: Collect Item button. \n| -Start: Starts the Game!\n| -End Game: Ends game and returns player to main menu.     " +
                    " |____________________________________________________________\n");

            // Calls the room information method, to create the rooms for the game.
            roomInformation();
    }
        //Enhancement: Introduced
        // Pressing the inventory button will trigger a small window detailing how many current items the player has.
        public void inventoryInformation() {
            // Utilizes the HashMap to retrieve room details for the current room.
            HashMap<String, String> currentRoom = rooms.get(current_room);

            // Sets the inventory text to the inventory text field within the game play activity.
            TextView inventoryText = findViewById(R.id.inventoryText);

            // Checks the current room and gets the item information.
            String roomItem = (rooms.get(current_room)).get("item");

            // If inventory is empty, displays inventory empty message.
            if (inventory.size() == 0) {
                // Sets inventory text to current inventory amount.
                inventoryText.setText("No items currently found.");
            }
            // Displays current inventory amount if above zero and less then seven.
            else if (inventory.size() < 7) {
                // Sets inventory text to current number of items collected.
                inventoryText.setText("You have collected: "+ roomItem + " "+ inventory.size() + "/7");
            }
            // If inventory is full, displays inventory full message.
            else if (inventory.size() == 7) {
                // Sets inventory text to all items found message.
                inventoryText.setText("ALL ITEMS FOUND!");
            }
        }

        // Sets up room game states for each room utilizing a hashmap.
        public void roomInformation() {

            // Utilizes the rooms hash map and creates the observatory room.
            rooms.put("Observatory", new HashMap<String, String>() {{
                // adds additional room information to the Observatory.
                put("West", "Personal Room");
                put("item", null);
                put("Story", "You have awoken in the observatory, the last thing you remember is viewing the stars. " +
                        "Your head is foggy and the room is a mess, smoke is filling the room. You look around " +
                        "and see a couple of doors, the West door looks intact and is the direction of your personal room.");
            }});

            // Utilizes the rooms hash map and creates the Personal Room.
            rooms.put("Personal Room", new HashMap<String, String>() {{
                // adds additional room information to the Personal Room.
                put("West", "Water Facility");
                put("East", "Observatory");
                put("item", "Pictures");
                put("Story", "You have arrived in your personal room. So many memories, so much will be left behind " +
                        "you look around for anything quick to grab and spot some pictures of your past. " +
                        "Time is running out, you have to move. The west door looks intact and is the direction " +
                        "of the Water Facility, the other doors are almost glowing red from heat, best to avoid the other directions.");
            }});

            // Utilizes the rooms hash map and creates the Water Facility room.
            rooms.put("Water Facility", new HashMap<String, String>() {{
                // adds additional room information to the Water Facility.
                put("North", "Garden");
                put("East", "Personal Room");
                put("item", "Water");
                put("Story", "The water facility looks to be in remarkably good shape considering everything that has happened. " +
                        "You drink as much water as you can and look around for the largest container you can find to store water for the journey" +
                        "You look around and see the door to the north seems mostly undamaged, you know the Garden is in that direction.");
            }});

            // Utilizes the rooms hash map and creates the Garden room.
            rooms.put("Garden", new HashMap<String, String>() {{
                // adds additional room information to the Garden.
                put("North", "Cafeteria");
                put("South", "Water Facility");
                put("item", "Seeds");
                put("Story", "The Garden is in worst shaped then you imagined, filled with smoke and fire. You grab a couple of fruits to eat unfortunately " +
                        "not much has survived. You remember there were emergency seed storage of all plants." +
                        "You look around and realize the Cafeteria is towards the East, unfortunately it appears the other paths have been destroyed.");
            }});

            // Utilizes the rooms hash map and creates the Cafeteria room.
            rooms.put("Cafeteria", new HashMap<String, String>() {{
                // adds additional room information to the Cafeteria.
                put("East", "Captains Room");
                put("South", "Garden");
                put("item", "Food");
                put("Story", "The Cafeteria is very hot and uncomfortable to be in for a long period of times you need to move." +
                        "You grab as much food as you can to fill your stomach and look around the room and find a case that can be filled with food." +
                        "The ships is starting to deteriorate faster, you have to move. The Captains room is to the East you need to find the Launch Code.");
            }});

            // Utilizes the rooms hash map and creates the Captains room.
            rooms.put("Captains Room", new HashMap<String, String>() {{
                // adds additional room information to the Captains Room.
                put("East", "Space Suit Locker");
                put("West", "Cafeteria");
                put("item", "Launch Code");
                put("Story", "The Captains room is in shambles, everything is all over the place and the air is dark due to smoke." +
                        "You search and look for any spot that the Captain could have potentially stored the Launch Codes." +
                        "You Look around and notice the Captains room leads directly to the Space Suit Locker to the East.");
            }});

            // Utilizes the rooms hash map and creates the Space Suit Locker room.
            rooms.put("Space Suit Locker", new HashMap<String, String>() {{
                // adds additional room information to the Space Suit Locker.
                put("South", "Hallway");
                put("West", "Captains Room");
                put("item", "Space Suit");
                put("Story", "The Space Suit Locker is mostly empty now, it looks like many others potentially escaped!" +
                        "You see a Space Suit but the locker is jammed and deformed. You manage to break it open." +
                        "In all of the destruction you hear a noise coming from the Hallway ahead. It is located to the south.");
            }});

            // Utilizes the rooms hash map and creates the Hallway room.
            rooms.put("Hallway", new HashMap<String, String>() {{
                // adds additional room information to the Hallway.
                put("West", "Escape Pod");
                put("North", "Space Suit Locker");
                put("item", "A Lost PUPPY!");
                put("Story", "You make it to the Hallway but it is quiet, you call out and hear a small sound. You realize it is a lost puppy! " +
                        "You try to persuade the puppy to come closer with some of your food you were eating earlier. " +
                        "You look around and notice your are right were you need to be! The ESCAPE POD IS TO THE WEST!");
            }});

            // Utilizes the rooms hash map and creates the Escape Pod room.
            rooms.put("Escape Pod", new HashMap<String, String>() {{
                // adds additional room information to the Escape Pod.
                put("East", "Hallway");
                put("item", null);
                put("Story", "Not many Escape Pods are left, some have been used while others have been destroyed. " +
                        "You find one that looks in good condition with little to no damage and contemplate the upcoming launch" +
                        "");
            }});
        }

        // Checks if current room has an item and displays message based on item information.
        public void collectItem() {
            // Utilizes the HashMap to retrieve room details for the current room.
            HashMap<String, String> currentRoom = rooms.get(current_room);

            // Checks to see if current room has an item and is not null.
            if (currentRoom.get("item") != null) {
                // Checks the current room and gets the item information.
                String roomItem = (rooms.get(current_room)).get("item");

                // Adds the item to the players inventory.
                inventory.add(roomItem);

                // Assigns inventory text to the InventoryText TextView.
                TextView inventoryText= findViewById(R.id.inventoryText);
                // Displays message prompted user the item was collected.
                inventoryText.setText("You have collected: " + roomItem);

                // Updates inventory information since an Item was collected.
                inventoryInformation();

                // Remove the item from the current room.
                currentRoom.remove("item");

            } else {

                // Assigns inventory text to the InventoryText TextView.
                TextView inventoryText= findViewById(R.id.inventoryText);
                // Displays message prompted user the item was collected.
                inventoryText.setText("No items are currently in this room!");
            }
        }

        // Moves the player in the direction chosen.
        public void travel(String cardinalDirections) {
            // Utilizes the HashMap to retrieve room details for the current room.
            HashMap<String, String> currentRoom = rooms.get(current_room);

            // Sets the game text to the game text field within the game play activity.
            TextView gameText = findViewById(R.id.game_text);

            // Ensures that collect button can be accessed from this method.
            Button collectButton = findViewById(R.id.collect_item_button);

            // Checks the current room and gets the room story
            String roomStory = (rooms.get(current_room)).get("Story");

            // Resets the click listener and the collect item button to ensure
            // game can continue after entering and leaving escape pod.
            collectButton.setText("Collect Item");
            collectButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Collects an Item within a room.
                    collectItem();
                }
            });

            // Checks room information using pressed cardinal direction.
            if (currentRoom.containsKey(cardinalDirections)) {
                current_room = currentRoom.get(cardinalDirections);
                // Checks the current room and gets the room story
                roomStory = (rooms.get(current_room)).get("Story");
                // Clears Inventory Text after entering a room.
                TextView inventoryText = findViewById(R.id.inventoryText);
                // Sets the Inventory Text to blank.
                inventoryText.setText("");
                gameText.setText("You have entered the " + current_room + ", There must be an item in " +
                        "this room that can aid in your survival." + "\n\n\n" + roomStory);

            } else {
                gameText.setText("The room you are trying to enter has been DESTROYED! Go in a different DIRECTION!");

            }

            // Checks to see if the player is in the escape pod and the amount of items the player has in their inventory.
            if (current_room.equals("Escape Pod") && inventory.size() == 7) {
                // Sets game text to let the player know they are in the escape pod and all items were collected. It is safe to Launch!
                gameText.setText("Well Done! You have all survival items required and you made it to the Escape Pod! \n" +
                        "\nNot much time is left now, LAUNCH!!! " + roomStory);

                // Changes the text on the collect item button to LAUNCH.
                collectButton.setText("LAUNCH!!!");

                // Checks to see if the player pressed the LAUNCH!!! button.
                collectButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // Launches the Escape Pod and ends the game!
                        victoryScreen();
                    }
                });
            }

            // Checks to see if the player is in the escape pod and the amount of items the player has in their inventory.
            if (current_room.equals("Escape Pod") && inventory.size() < 7) {
                // Sets game text to let the player know they are in the escape pod and all items were collected. It is safe to Launch!
                gameText.setText("STOP! You do not have all items needed for survival, Launching would surely lead to DEATH!!! \n" +
                        "\n*Choose to ignore all of the warnings and press Launch out of fear*");

                // Changes the text on the collect item button to LAUNCH.
                collectButton.setText("LAUNCH!!!");

                // Checks to see if the player pressed the LAUNCH!!! button.
                collectButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // Launches the Escape Pod and ends the game!
                        defeatScreen();
                        }
                    });
                }
        }

        // Victory screen which will display if the player has reached the escape pod and has all seven items within their inventory.
        public void victoryScreen() {
            // Sets the game text to the game text field within the game play activity.
            TextView gameText = findViewById(R.id.game_text);
            gameText.setText("\t\t\t\t\t\t\t\t\t\tCONGRATULATIONS!!! \n" +
                    "You have made it to the escape pod and have all items needed to survive.\n" +
                    "You and your new friend have made it to safety and survived! \n" +
                    "\n" +
                    " You Saved a wonderful puppy, you named it Nirvana!");

            // Sets up the puppy image with the ImageView.
            ImageView puppy = findViewById(R.id.puppy_image);
            // When in the Victory Screen enables the visibility of the puppy image.
            puppy.setVisibility(View.VISIBLE);

            // Activates and reacts to the activation start game button.
            Button startButton = findViewById(R.id.start_button);
            // Sets start button to be enabled by default.
            startButton.setEnabled(false);

            // Activates and reacts to the activation end game button.
            Button endGameButton = findViewById(R.id.end_game_button);
            // Sets end game button to be enabled by default.
            endGameButton.setEnabled(true);

            // Sets the login button to be disabled as long as the game has not been started.
            Button inventoryButton = findViewById(R.id.view_inventory_button);
            // Sets Inventory button to be disabled by default.
            inventoryButton.setEnabled(false);

            // Sets the collect item button to be disabled as long as the game has not been started.
            Button collectItemButton = findViewById(R.id.collect_item_button);
            // Sets Collect Item button to be disabled by default.
            collectItemButton.setEnabled(false);

            // Sets the north button to be disabled as long as the game has not been started.
            Button northButton = findViewById(R.id.north_button);
            // Sets north button to be disabled by default.
            northButton.setEnabled(false);

            // Sets the south button to be disabled as long as the game has not been started.
            Button southButton = findViewById(R.id.south_button);
            // Sets south button to be disabled by default.
            southButton.setEnabled(false);

            // Sets the east button to be disabled as long as the game has not been started.
            Button eastButton = findViewById(R.id.east_button);
            // Sets east button to be disabled by default.
            eastButton.setEnabled(false);

            // Sets the west button to be disabled as long as the game has not been started.
            Button westButton = findViewById(R.id.west_button);
            // Sets west button to be disabled by default.
            westButton.setEnabled(false);
        }

        // Defeat screen which will display if the player has reached the escape pod and has chosen to launch without all seven items within their inventory.
        public void defeatScreen() {
            // Sets the game text to the game text field within the game play activity.
            TextView gameText = findViewById(R.id.game_text);
            gameText.setText("\t\t\t\t\t\t\t\t\t\tEscape Failed! \n" +
                    "Although you successfully made it to the escape pod, you did not gather enough " +
                    "survival items to survive the trip. Although you are safe from the meteors, " +
                    "you were unable to survive the journey back home.");

            // Activates and reacts to the activation start game button.
            Button startButton = findViewById(R.id.start_button);
            // Sets start button to be enabled by default.
            startButton.setEnabled(false);

            // Activates and reacts to the activation end game button.
            Button endGameButton = findViewById(R.id.end_game_button);
            // Sets end game button to be enabled by default.
            endGameButton.setEnabled(true);

            // Sets the login button to be disabled as long as the game has not been started.
            Button inventoryButton = findViewById(R.id.view_inventory_button);
            // Sets Inventory button to be disabled by default.
            inventoryButton.setEnabled(false);

            // Sets the collect item button to be disabled as long as the game has not been started.
            Button collectItemButton = findViewById(R.id.collect_item_button);
            // Sets Collect Item button to be disabled by default.
            collectItemButton.setEnabled(false);

            // Sets the north button to be disabled as long as the game has not been started.
            Button northButton = findViewById(R.id.north_button);
            // Sets north button to be disabled by default.
            northButton.setEnabled(false);

            // Sets the south button to be disabled as long as the game has not been started.
            Button southButton = findViewById(R.id.south_button);
            // Sets south button to be disabled by default.
            southButton.setEnabled(false);

            // Sets the east button to be disabled as long as the game has not been started.
            Button eastButton = findViewById(R.id.east_button);
            // Sets east button to be disabled by default.
            eastButton.setEnabled(false);

            // Sets the west button to be disabled as long as the game has not been started.
            Button westButton = findViewById(R.id.west_button);
            // Sets west button to be disabled by default.
            westButton.setEnabled(false);
        }
}