/*
Author: Mark Irwin
Date: 9/24/2024
Version: 1.1

Description: Main Activity represents the Main menu of the application. Features buttons to start
the game, enter the leaderboard screen, and exit the game.

*/

package com.example.capstone_spaceship_escape_mark_irwin;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Main Menu start game button.
        Button startGameButton = findViewById(R.id.start_game_button);
        startGameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the Game Activity.
                Intent intent = new Intent(MainActivity.this, GamePlayActivity.class);
                startActivity(intent);
            }
        });

        // Main Menu leaderboard button.
        Button leaderboardButton = findViewById(R.id.leaderboard_button);
        leaderboardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the leaderboard activity.
                Intent intent = new Intent(MainActivity.this, LeaderboardActivity.class);
                startActivity(intent);
            }
        });

        // Main Menu Exit Game button.
        Button exitGameButton = findViewById(R.id.exit_game_button);
        exitGameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Exit the game and completely close the application.
                finishAndRemoveTask();
            }
        });
    }
}