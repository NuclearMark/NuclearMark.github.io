/*
Author: Mark Irwin
Date: 10/3/2024
Version: 1.3

Description: Leaderboard Activity represents the leaderboard menu within the starship escape game.
This currently allows users to enter the leaderboard screen and return back to the main menu.

ENHANCEMENT: Created a retrieve function and a display function so that leaderboard activity would
properly display the top ten player names and fastest completion times. This allowed clear and finalized
usage of my leaderboards menu that I created during enhancement one.
*/

package com.example.capstone_spaceship_escape_mark_irwin;


import android.content.Intent;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class LeaderboardActivity extends AppCompatActivity {
    // Declares linear layout as the leaderboard layout for the top 10 displayed.
    private LinearLayout leaderboardLayout;
    // Warning text used as an error check to alert players of errors and how to navigate.
    private TextView warningText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.leaderboard);
        // Maps the leaderboard layout to the xml counterpart.
        leaderboardLayout = findViewById(R.id.leaderboard_layout);

        // Maps the return to menu button to the xml counterpart.
        Button returnMenuButton = findViewById(R.id.return_menu_button);
        // Listener attached to the return to menu button.
        returnMenuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Return to the Main Menu.
                Intent intent = new Intent(LeaderboardActivity.this, MainActivity.class);
                // Ensures that the main menu activity will always be closed when pressing the exit game button.
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });

        // Fetch leaderboard entries when the activity is created
        retrieveLeaderboardEntries();
    }
    /*
    ENHANCEMENT: Retrieves scores from the leaderboards collection within the firebase Spaceship
    Escape database.
     */
    private void retrieveLeaderboardEntries() {
        // Gets database information from the firebase database and stores it.
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("leaderboard");
        //  Adds listener to variable connected to firebase leaderboard.
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                // Creates an array list for entries.
                List<LeaderboardEntry> entries = new ArrayList<>();
                // Retrieves leaderboard data through a data snapshot.
                for (DataSnapshot entrySnapshot : snapshot.getChildren()) {
                    LeaderboardEntry entry = entrySnapshot.getValue(LeaderboardEntry.class);
                    // As long as entry is not null add it as an entry.
                    if (entry != null) {
                        entries.add(entry);
                    }
                }

                // Sort entries by completion time from fastest to slowest.
                Collections.sort(entries, new Comparator<LeaderboardEntry>() {
                    @Override
                    // Compares leaderboard entries against eachother to determine fastest.
                    public int compare(LeaderboardEntry o1, LeaderboardEntry o2) {
                        return Long.compare(o1.getCompletionTime(), o2.getCompletionTime());
                    }
                });

                // Display only the top 10 entries
                displayTopTenEntries(entries);
            }

            // Ensures an error message goes through if no connection is made with the database.
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                warningText.setText("Failed to load leaderboard. Please try again later.");
            }
        });
    }
    /*
    ENHANCEMENT: Through the use of a firebase database displays the top 10 fastest times onto the
    leaderboard layout. Also ensures to adjust the visual appearance of the leaderboard to encourage
    better readability.
     */
    private void displayTopTenEntries(List<LeaderboardEntry> entries) {
        // Removes previous leaderboard results to ensure updated leaderboard can be showcased.
        leaderboardLayout.removeAllViews();

        // Fills the leaderboard count with the size of the entries count with a max of 10.
        int count = Math.min(entries.size(), 10);
        // Loop through the entries placing each entry into view.
        for (int i = 0; i < count; i++) {
            LeaderboardEntry entry = entries.get(i);
            // Variable for each entry completion time.
            long completionTime = entry.getCompletionTime();

            // Convert milliseconds to minutes and seconds.
            long seconds = (completionTime / 1000) % 60;
            long minutes = (completionTime / 1000) / 60;

            // Formats the time so it displays as minutes:seconds.
            String formattedTime = String.format("%02d:%02d", minutes, seconds);

            // Creates new text view named entry view.
            TextView entryView = new TextView(this);
            // Formats the leaderboard layout.
            entryView.setText((i + 1) + ". " + entry.getPlayerName() + " - " + formattedTime);
            // Adjusts the size of the leaderboard entries text.
            entryView.setTextSize(22);
            // Changes the text color to neon green to match the theme of the game.
            entryView.setTextColor(Color.parseColor("#7FFF00"));
            // Aligns the leaderboard text to the center of the view.
            entryView.setGravity(Gravity.CENTER_HORIZONTAL);
            // Adds the entry view to the leaderboard layout.
            leaderboardLayout.addView(entryView);
        }
    }

}