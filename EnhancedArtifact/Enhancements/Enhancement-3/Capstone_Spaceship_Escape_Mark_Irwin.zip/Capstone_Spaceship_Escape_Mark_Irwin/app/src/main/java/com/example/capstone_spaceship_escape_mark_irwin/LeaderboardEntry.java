/*
Author: Mark Irwin
Date: 10/3/2024
Version: 1.3

Description: Leaderboard Entry represents the ability set and get the two main database variables.

ENHANCEMENT: I created setter and getter functions to add and retrieve data from the Spaceship Escape
Firebase Database under the leaderboard collection.
*/

package com.example.capstone_spaceship_escape_mark_irwin;

public class LeaderboardEntry {
    // Variable for the players name.
    private String playerName;
    // Variable for the players completion time.
    private long completionTime;

    // Constructor required for Firebase
    public LeaderboardEntry() {
    }

    // Leaderboard entry for the players name and players completion time.
    public LeaderboardEntry(String playerName, long completionTime) {
        this.playerName = playerName;
        this.completionTime = completionTime;
    }

    // Getter for the players name.
    public String getPlayerName() {
        return playerName;
    }

    // Setter for the players name.
    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    // Getter for the players completion time.
    public long getCompletionTime() {
        return completionTime;
    }

    // Setter for the players completion time.
    public void setCompletionTime(long completionTime) {
        this.completionTime = completionTime;
    }
}