/*
Author: Mark Irwin
Date: 9/28/2024
Version: 1.2

Description: This code Represents a text based adventure within the Android Studio environment in
Java. The core of the game revolves around a player utilizing the movement buttons to explore
a damage space station, collecting items from each room, then finally finding the escape pod to
escape to safety if all items were found successfully.

GamePlayActivity represents logic for creation, room movement, inventory management, end of
game states, and button logic.

Enhancement: Added an 10 minute timer to the games start button. This ensures that when the game
officially starts a countdown is started at the same time. It also stops the timer and records
how long it took the player to finish the game. Also added an enhancement for room randomization.
This involved having a large amount of extra rooms but instead of having the map be pre-designed
the game would randomize what maps the player encountered everytime a new game was started. This
helps add time constraint and randomization.

*/

package com.example.capstone_spaceship_escape_mark_irwin;

import static java.lang.System.out;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;



public class GamePlayActivity extends AppCompatActivity {

    // Creates hash map that will store room information.
    HashMap<String, HashMap<String, String>> rooms = new HashMap<>();

    // Creates an array list that will be utilized for the player inventory.
    ArrayList<String> inventory = new ArrayList<>();

    // Sets starting room to the Observatory.
    String current_room = "Observatory";

    // Sets countdown timer variable.
    CountDownTimer timer;

    // Sets variable for remaining time.
    long remainingTime = 600000;

    // When the start game button is pushed on the main menu will load the start of
    // the game. This ensures all buttons are enabled or disabled by default for the purpose of
    // functionality.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Sets current view to game play activity.
        setContentView(R.layout.gameplay_loop);

        // Sets the game text to the game text field within the game play activity.
        TextView gameText = findViewById(R.id.game_text);

        // Sets up the puppy image with the ImageView.
        ImageView puppy = findViewById(R.id.puppy_image);

        // When game starts ensures the puppy image is not visible.
        puppy.setVisibility(View.GONE);

        // Sets the introduction and rules messages as the default on creation.
        gameText.setText("\t\t\t\t\t\t\t\t\t\tSPACESHIP ESCAPE!!!\n" +
                "\nYou are a star traveler and you have awoken to your ships alarms going off!" +
                " Meteors are coming and your engine has been disabled from a smaller meteor, " +
                " you immediately realize the seriousness of your situation and know survival " +
                "is all that matters now. \n\nMake your way through your ship, " +
                "enter what ever rooms you can that have not been damaged and collect survival items.\n" +
                "\nOnce you have collected all seven survival items find your way to the escape pod.\n" +
                "\nYou need to collect seven items to be able to survive the trip in the escape pod. \n\n" +
                "*Remember though, you need all SEVEN items to survive and win. " +
                "Forcing the escape pod to launch without all seven items will end the game as survival would not be possible.*" +
                "\n\n\t\t\t\t\t\t\tPlease press START to start the game!");

        // Activates and reacts to the activation start game button.
        Button startButton = findViewById(R.id.start_button);
        // Sets start button to be enabled by default.
        startButton.setEnabled(true);

        // Activates and reacts to the activation end game button.
        Button endGameButton = findViewById(R.id.end_game_button);
        // Sets end game button to be enabled by default.
        endGameButton.setEnabled(true);

        // Sets the login button to be disabled as long as the game has not been started.
        Button inventoryButton = findViewById(R.id.view_inventory_button);
        // Sets Inventory button to be disabled by default.
        inventoryButton.setEnabled(false);

        // Sets the collect item button to be disabled as long as the game has not been started.
        Button collectItemButton = findViewById(R.id.collect_item_button);
        // Sets Collect Item button to be disabled by default.
        collectItemButton.setEnabled(false);

        // Sets the north button to be disabled as long as the game has not been started.
        Button northButton = findViewById(R.id.north_button);
        // Sets north button to be disabled by default.
        northButton.setEnabled(false);

        // Sets the south button to be disabled as long as the game has not been started.
        Button southButton = findViewById(R.id.south_button);
        // Sets south button to be disabled by default.
        southButton.setEnabled(false);

        // Sets the east button to be disabled as long as the game has not been started.
        Button eastButton = findViewById(R.id.east_button);
        // Sets east button to be disabled by default.
        eastButton.setEnabled(false);

        // Sets the west button to be disabled as long as the game has not been started.
        Button westButton = findViewById(R.id.west_button);
        // Sets west button to be disabled by default.
        westButton.setEnabled(false);

        // If end game button is pressed returns the player back to the main menu.
        endGameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Return to the Main Menu.
                Intent intent = new Intent(GamePlayActivity.this, MainActivity.class);
                // Ensures that the main menu activity will always be closed when pressing the exit game button.
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });

        // Acknowledges you understand the rules of the game and starts the game.
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Confirms the user has read the games instructions and is ready to play.
                startGame();
                startTime();
            }
        });

        // Opens the inventory information tab.
        inventoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Shows the player how many items are currently in their inventory.
                inventoryInformation();
            }
        });

        // Attempts to collect an item in the current room.
        collectItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Attempts to collect an item from the current room and adds it to the players inventory.
                collectItem();
            }
        });

        // Checks to see if the player pressed the north button.
        northButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Moves the player in the direction of north.
                travel("North");
            }
        });

        // Checks to see if the player pressed the south button.
        southButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Moves the player in the direction of south.
                travel("South");
            }
        });

        // Checks to see if the player pressed the east button.
        eastButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Moves the player in the direction of east.
                travel("East");
            }
        });

        // Checks to see if the player pressed the west button.
        westButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Moves the player in the direction of west.
                travel("West");
            }
        });
    }

    // Starts the game play loop triggering all buttons to enable except start and allows player movements.
    public void startGame() {
        // Activates and reacts to the activation start game button.
        Button startButton = findViewById(R.id.start_button);
        // Sets start button to be disabled.
        startButton.setEnabled(false);

        // Activates and reacts to the activation end game button.
        Button endGameButton = findViewById(R.id.end_game_button);
        // Sets end game button to be enabled.
        endGameButton.setEnabled(true);

        // Sets the login button to be enabled.
        Button inventoryButton = findViewById(R.id.view_inventory_button);
        // Sets Inventory button to be enabled.
        inventoryButton.setEnabled(true);

        // Sets the collect item button to be enabled.
        Button collectItemButton = findViewById(R.id.collect_item_button);
        // Sets Collect Item button to be enabled.
        collectItemButton.setEnabled(true);

        // Sets the north button to be enabled.
        Button northButton = findViewById(R.id.north_button);
        // Sets north button to be enabled.
        northButton.setEnabled(true);

        // Sets the south button to be enabled.
        Button southButton = findViewById(R.id.south_button);
        // Sets south button to be enabled.
        southButton.setEnabled(true);

        // Sets the east button to be enabled.
        Button eastButton = findViewById(R.id.east_button);
        // Sets east button to be enabled.
        eastButton.setEnabled(true);

        // Sets the west button to be enabled.
        Button westButton = findViewById(R.id.west_button);
        // Sets west button to be enabled.
        westButton.setEnabled(true);

        // Sets the game text to the game text field within the game play activity.
        TextView gameText = findViewById(R.id.game_text);

        // Sets game text to current situation within the game.
        gameText.setText("You have awoken in the Observatory! No items of importance appear to be in this room, " +
                "Choose which direction you would like to travel towards. \n\n\n" + "You have awoken in the observatory, the last thing you remember is viewing the stars." +
                "Your head is foggy and the room is a mess, smoke is filling the room. You look around\n" +
                "and see a couple of doors, It is time to head for one and see what you can do to survive.\n\n\n\n" +
                "___________________________________________________________\n" +
                "| Goal: Find all SEVEN survival items and LAUNCH the               | Escape Pod!\n" +
                "| Controls: \n| -Inventory: Displays your current Inventory Progress \n| -Player Movement: North, South, East, West \n|" +
                " -Item Collection: Collect Item button. \n| -Start: Starts the Game!\n| -End Game: Ends game and returns player to main menu.     " +
                " |__________________________________________________________\n");

        // Calls the room information method, to create the rooms for the game.
        roomInformation();
        // Randomizes the spaceship escape map.
        roomSetup();
    }

    //Enhancement: Introduced
    // Pressing the inventory button will trigger a small window detailing how many current items the player has.
    public void inventoryInformation() {
        // Utilizes the HashMap to retrieve room details for the current room.
        HashMap<String, String> currentRoom = rooms.get(current_room);

        // Sets the inventory text to the inventory text field within the game play activity.
        TextView inventoryText = findViewById(R.id.inventoryText);

        // Checks the current room and gets the item information.
        String roomItem = (rooms.get(current_room)).get("item");

        // If inventory is empty, displays inventory empty message.
        if (inventory.size() == 0) {
            // Sets inventory text to current inventory amount.
            inventoryText.setText("No items currently found.");
        }
        // Displays current inventory amount if above zero and less then seven.
        else if (inventory.size() < 7) {
            // Sets inventory text to current number of items collected.
            inventoryText.setText("You have collected: " + roomItem + " " + inventory.size() + "/7");
        }
        // If inventory is full, displays inventory full message.
        else if (inventory.size() == 7) {
            // Sets inventory text to all items found message.
            inventoryText.setText("ALL ITEMS FOUND!");
        }
    }

    // Sets up room game states for each room utilizing a hashmap.
    public void roomInformation() {

        // Utilizes the rooms hash map and creates the observatory room.
        rooms.put("Observatory", new HashMap<String, String>() {{
            // adds additional room information to the Observatory.
            put("item", null);
            put("Story", "You have awoken in the observatory, the last thing you remember is viewing the stars. " +
                    "Your head is foggy and the room is a mess, smoke is filling the room. You look around " +
                    "and see a couple of doors.");
        }});

        // Utilizes the rooms hash map and creates the Personal Room.
        rooms.put("Personal Room", new HashMap<String, String>() {{
            // adds additional room information to the Personal Room.
            put("item", "Pictures");
            put("Story", "You have arrived in your personal room. So many memories, so much will be left behind " +
                    "you look around for anything quick to grab and spot some pictures of your past. " +
                    "Time is running out, you have to move.");
        }});

        // Utilizes the rooms hash map and creates the Water Facility room.
        rooms.put("Water Facility", new HashMap<String, String>() {{
            // adds additional room information to the Water Facility.
            put("item", "Water");
            put("Story", "The water facility looks to be in remarkably good shape considering everything that has happened. " +
                    "You drink as much water as you can and look around for the largest container you can find to store water for the journey");
        }});

        // Utilizes the rooms hash map and creates the Garden room.
        rooms.put("Garden", new HashMap<String, String>() {{
            // adds additional room information to the Garden.
            put("item", "Seeds");
            put("Story", "The Garden is in worst shaped then you imagined, filled with smoke and fire. You grab a couple of fruits to eat unfortunately " +
                    "not much has survived. You remember there were emergency seed storage of all plants.");
        }});

        // Utilizes the rooms hash map and creates the Cafeteria room.
        rooms.put("Cafeteria", new HashMap<String, String>() {{
            // adds additional room information to the Cafeteria.
            put("item", "Food");
            put("Story", "The Cafeteria is very hot and uncomfortable to be in for a long period of times you need to move." +
                    "You grab as much food as you can to fill your stomach and look around the room and find a case that can be filled with food." +
                    "The ships is starting to deteriorate faster, you have to move.");
        }});

        // Utilizes the rooms hash map and creates the Captains room.
        rooms.put("Captains Room", new HashMap<String, String>() {{
            // adds additional room information to the Captains Room.
            put("item", "Launch Code");
            put("Story", "The Captains room is in shambles, everything is all over the place and the air is dark due to smoke." +
                    "You search and look for any spot that the Captain could have potentially stored the Launch Codes.");
        }});

        // Utilizes the rooms hash map and creates the Space Suit Locker room.
        rooms.put("Space Suit Locker", new HashMap<String, String>() {{
            // adds additional room information to the Space Suit Locker.
            put("item", "Space Suit");
            put("Story", "The Space Suit Locker is mostly empty now, it looks like many others potentially escaped!" +
                    "You see a Space Suit but the locker is jammed and deformed. You manage to break it open.");
        }});

        // Utilizes the rooms hash map and creates the Hallway room.
        rooms.put("Hallway", new HashMap<String, String>() {{
            // adds additional room information to the Hallway.
            put("item", "A Lost PUPPY!");
            put("Story", "You make it to the Hallway but it is quiet, you call out and hear a small sound. You realize it is a lost puppy! " +
                    "You try to persuade the puppy to come closer with some of your food you were eating earlier. ");
        }});

        // Utilizes the rooms hash map and creates the Escape Pod room.
        rooms.put("Escape Pod", new HashMap<String, String>() {{
            // adds additional room information to the Escape Pod.
            put("item", null);
            put("Story", "Not many Escape Pods are left, some have been used while others have been destroyed. " +
                    "You find one that looks in good condition with little to no damage and contemplate the upcoming launch" +
                    "");
        }});

        // Utilizes the rooms hash map and creates the Laboratory room.
        rooms.put("Laboratory", new HashMap<String, String>() {{
            // adds additional room information to the Laboratory.
            put("item", "Research Notes");
            put("Story", "You have found yourself located in the Laboratory. Collecting research notes could help share your research. " +
                    "You look around for your research notes as the data is too valuable to leave behind.");
        }});

        // Utilizes the rooms hash map and creates the Library room.
        rooms.put("Library", new HashMap<String, String>() {{
            // adds additional room information to the Library.
            put("item", "Historic Documents");
            put("Story", "You have found yourself located in the Library. The ship is doomed but historic documents are located within the Library! " +
                    "The room is in disarray it is hard to see but finding those historic documents are required for information preservation.");
        }});

        // Utilizes the rooms hash map and creates the Engine room.
        rooms.put("Engine Room", new HashMap<String, String>() {{
            // adds additional room information to the Engine Room.
            put("item", "Tools");
            put("Story", "You have found yourself located in the Engine Room. Collecting tools could help you in case the escape pod is damaged. " +
                    "You look around for any tools you can find while realizing the engine can no longer be fixed and you need to move.");
        }});

        // Utilizes the rooms hash map and creates the Medical Bay room.
        rooms.put("Medical Bay", new HashMap<String, String>() {{
            // adds additional room information to the Medical Bay.
            put("item", "Medical Supplies");
            put("Story", "You have found yourself located in the Medical Bay. Collecting medical supplies could be important for survival or in case you find others. " +
                    "You look around the medical bay and realize alot has either been destroyed or taken, you look to gather what you can.");
        }});

        // Utilizes the rooms hash map and creates the Space Walk room.
        rooms.put("Space Walk", new HashMap<String, String>() {{
            // adds additional room information to the Space Walk.
            put("item", "Space Boots");
            put("Story", "You have found yourself located in the Space walk. Collecting space boots will be vital to survival. " +
                    "You look around for your space boots through the rubble, this use to be one of your favorite past times.");
        }});

        // Utilizes the rooms hash map and creates the Gaming room.
        rooms.put("Gaming Room", new HashMap<String, String>() {{
            // adds additional room information to the Gaming Room.
            put("item", "Nintendo Switch");
            put("Story", "You have found yourself located in the gaming room. This rooms provides little for survival but you are determined to find something to pass the time in the escape pod. " +
                    "You look around for your Nintendo Switch and hope it is not damaged.");
        }});

        // Utilizes the rooms hash map and creates the Communications room.
        rooms.put("Communications Room", new HashMap<String, String>() {{
            // adds additional room information to the Communications.
            put("item", "Survival Beacon");
            put("Story", "You have found yourself located in the Communication Room. Collecting a Survival Beacon is key to the success of your upcoming journey. " +
                    "you look around for the survival beacon as the beacon is too valuable to leave behind.");
        }});

        // Utilizes the rooms hash map and creates the RESTRICTED ACCESS Room.
        rooms.put("RESTRICTED ACCESS!!!", new HashMap<String, String>() {{
            // adds additional room information to the RESTRICTED ACCESS Room.
            put("item", "ALIEN?");
            put("Story", "You have found yourself located in a room you do not recognize the door was destroyed but on it said restricted access. You see something you do not recognize in a small glass cube. " +
                    "You look around trying to gather yourself. It looks alive...Do you take it with you, is saving it the right thing?");
        }});
    }

    // Checks if current room has an item and displays message based on item information.
    public void collectItem() {
        // Utilizes the HashMap to retrieve room details for the current room.
        HashMap<String, String> currentRoom = rooms.get(current_room);

        // Checks to see if current room has an item and is not null.
        if (currentRoom.get("item") != null) {
            // Checks the current room and gets the item information.
            String roomItem = (rooms.get(current_room)).get("item");

            // Adds the item to the players inventory.
            inventory.add(roomItem);

            // Assigns inventory text to the InventoryText TextView.
            TextView inventoryText = findViewById(R.id.inventoryText);
            // Displays message prompted user the item was collected.
            inventoryText.setText("You have collected: " + roomItem);

            // Updates inventory information since an Item was collected.
            inventoryInformation();

            // Remove the item from the current room.
            currentRoom.remove("item");

        } else {

            // Assigns inventory text to the InventoryText TextView.
            TextView inventoryText = findViewById(R.id.inventoryText);
            // Displays message prompted user the item was collected.
            inventoryText.setText("No items are currently in this room!");
        }
    }

    // Moves the player in the direction chosen.
    public void travel(String cardinalDirections) {
        // Utilizes the HashMap to retrieve room details for the current room.
        HashMap<String, String> currentRoom = rooms.get(current_room);

        // Sets the game text to the game text field within the game play activity.
        TextView gameText = findViewById(R.id.game_text);

        // Ensures that collect button can be accessed from this method.
        Button collectButton = findViewById(R.id.collect_item_button);

        // Checks the current room and gets the room story
        String roomStory = (rooms.get(current_room)).get("Story");

        // Resets the click listener and the collect item button to ensure
        // game can continue after entering and leaving escape pod.
        collectButton.setText("Collect Item");
        collectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Collects an Item within a room.
                collectItem();
            }
        });

        // Checks room information using pressed cardinal direction.
        if (currentRoom.containsKey(cardinalDirections)) {
            current_room = currentRoom.get(cardinalDirections);
            // Checks the current room and gets the room story
            roomStory = (rooms.get(current_room)).get("Story");
            // Clears Inventory Text after entering a room.
            TextView inventoryText = findViewById(R.id.inventoryText);
            // Sets the Inventory Text to blank.
            inventoryText.setText("");
            gameText.setText("You have entered the " + current_room + ", There must be an item in " +
                    "this room that can aid in your survival." + "\n\n\n" + roomStory);

        } else {
            gameText.setText("The room you are trying to enter has been DESTROYED! Go in a different DIRECTION!");

        }

        // Checks to see if the player is in the escape pod and the amount of items the player has in their inventory.
        if (current_room.equals("Escape Pod") && inventory.size() == 7) {
            // Sets game text to let the player know they are in the escape pod and all items were collected. It is safe to Launch!
            gameText.setText("Well Done! You have all survival items required and you made it to the Escape Pod! \n" +
                    "\nNot much time is left now, LAUNCH!!! " + roomStory);

            // Changes the text on the collect item button to LAUNCH.
            collectButton.setText("LAUNCH!!!");

            // Checks to see if the player pressed the LAUNCH!!! button.
            collectButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Launches the Escape Pod and ends the game!
                    victoryScreen();
                }
            });
        }

        // Checks to see if the player is in the escape pod and the amount of items the player has in their inventory.
        if (current_room.equals("Escape Pod") && inventory.size() < 7) {
            // Sets game text to let the player know they are in the escape pod and all items were collected. It is safe to Launch!
            gameText.setText("STOP! You do not have all items needed for survival, Launching would surely lead to DEATH!!! \n" +
                    "\n*Choose to ignore all of the warnings and press Launch out of fear*");

            // Changes the text on the collect item button to LAUNCH.
            collectButton.setText("LAUNCH!!!");

            // Checks to see if the player pressed the LAUNCH!!! button.
            collectButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Launches the Escape Pod and ends the game!
                    defeatScreen();
                }
            });
        }
    }

    /* ENHANCEMENT: Starts timer which ensures the countdown begins.
    Utilizes milliseconds to ensure accuracy and precision during the count down process.

    Trade Off: Although adding a timer might pressure players into feeling rushed and in a sense
    discourage exploration, It will encourage urgency and immersion to the story which would be a benefit.
    */
    // Starts countdown timer starting from 10 minutes. Counts down utilizing milliseconds.
    public void startTime() {
        // Optimization: Utilizing Countdown timer helped with efficient handling of the time countdown I
        // wanted to utilize with Spaceship Escape and allows the player to see consistent and accurate real
        // time updates.

        // Time Complexity: Although the initial time choice for the countdown timer would be O(n) based on
        // the number of milliseconds, The overall ticks of each second would involve constant progression
        // which would be O(1).

        // Efficiency of Algorithmic Logic: By utilizing a countdown timer the gameplay experience becomes
        // more immersive and provides real time feedback and enhancement to the player. The timer serves the
        // purpose of not only adding urgency to the system but also helps the player become deeper immersed within
        // the contents of the gameplay and story.

        // Textview for the countdown timer.
        TextView countdownTimerText = findViewById(R.id.countdown_timer);

        // Sets countdown timer to 10 minutes,
        timer = new CountDownTimer(remainingTime, 1000) {

            @Override
            public void onTick(long millisUntilFinished) {
                remainingTime = millisUntilFinished;

                // Time Complexity: O(1) Has constant time complexity as each tick remains consistent.
                long minutes = ((millisUntilFinished / 1000) % 3600) / 60;
                // Time Complexity: O(1) Has constant time complexity as each tick remains consistent.
                long seconds = (millisUntilFinished / 1000) % 60;

                // Formats the time to ensure it reads as minutes : seconds.
                // Time Complexity: O(1) Has constant time complexity as each tick remains consistent.
                String formatTime = String.format("%02d:%02d", minutes, seconds);

                // Update Textview to ensure countdown timer is functionally properly.
                countdownTimerText.setText(formatTime);

                // Enhancement: Helps add to the players urgency.
                // Change the timer color to red when there are less than 3 minutes remaining.
                if (millisUntilFinished <= 181000) {
                    countdownTimerText.setTextColor(getColor(R.color.countdown_timer_red));
                }
            }

            @Override
            public void onFinish() {
                // Message that displays when the timer finishes.countdownTimerText.SetText("DEAD!");
                countdownTimerText.setText("DEAD!!!");
                // Triggers the defeat screen.
                timedDefeatScreen();
            }
        };
        // Time Complexity: O(1) Starts the timer for the time to count down. Time is constant throughout gameplay.
        timer.start();
    }

    // Stops the countdown timer.
    public void stopTimer() {
        if (timer != null) {
            // Time Complexity: O(1) Ending the timer would be considered constant since it is always running consistently.
            timer.cancel();
        }
    }

    /*
    ENHANCEMENT: Adds a timer solution, to find how long it took the player to reach the victory
    screen.
     */
    // Victory screen which will display if the player has reached the escape pod and has all seven items within their inventory.
    public void victoryScreen() {
        // Stops the timer.
        stopTimer();

        // Calculates time taken for player to reach the victory screen.
        long timeTaken = 600000 - remainingTime;
        long secondsTaken = (long) Math.ceil(timeTaken + 1000) / 1000;

        // Formats the time taken to display in remaining minutes and seconds.
        String timeTakenFormatted = String.format("%02d:%02d", (secondsTaken / 60), (secondsTaken % 60));

        // Sets the game text to the game text field within the game play activity.
        TextView gameText = findViewById(R.id.game_text);
        gameText.setText("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tCONGRATULATIONS!!! \n" +
                "You have made it to the escape pod and have all items needed to survive.\n" +
                "You and your new friend have made it to safety and survived! \n" +
                "\n" +
                " You Saved a wonderful puppy, you named it Nirvana!\n" +
                "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tTime to reach the end: " + timeTakenFormatted);

        // Sets up the puppy image with the ImageView.
        ImageView puppy = findViewById(R.id.puppy_image);
        // When in the Victory Screen enables the visibility of the puppy image.
        puppy.setVisibility(View.VISIBLE);

        // Activates and reacts to the activation start game button.
        Button startButton = findViewById(R.id.start_button);
        // Sets start button to be enabled by default.
        startButton.setEnabled(false);

        // Activates and reacts to the activation end game button.
        Button endGameButton = findViewById(R.id.end_game_button);
        // Sets end game button to be enabled by default.
        endGameButton.setEnabled(true);

        // Sets the login button to be disabled as long as the game has not been started.
        Button inventoryButton = findViewById(R.id.view_inventory_button);
        // Sets Inventory button to be disabled by default.
        inventoryButton.setEnabled(false);

        // Sets the collect item button to be disabled as long as the game has not been started.
        Button collectItemButton = findViewById(R.id.collect_item_button);
        // Sets Collect Item button to be disabled by default.
        collectItemButton.setEnabled(false);

        // Sets the north button to be disabled as long as the game has not been started.
        Button northButton = findViewById(R.id.north_button);
        // Sets north button to be disabled by default.
        northButton.setEnabled(false);

        // Sets the south button to be disabled as long as the game has not been started.
        Button southButton = findViewById(R.id.south_button);
        // Sets south button to be disabled by default.
        southButton.setEnabled(false);

        // Sets the east button to be disabled as long as the game has not been started.
        Button eastButton = findViewById(R.id.east_button);
        // Sets east button to be disabled by default.
        eastButton.setEnabled(false);

        // Sets the west button to be disabled as long as the game has not been started.
        Button westButton = findViewById(R.id.west_button);
        // Sets west button to be disabled by default.
        westButton.setEnabled(false);
    }

    // Defeat screen which will display if the player has reached the escape pod and has chosen to launch without all seven items within their inventory.
    public void defeatScreen() {
        // Sets the game text to the game text field within the game play activity.
        TextView gameText = findViewById(R.id.game_text);
        gameText.setText("\t\t\t\t\t\t\t\t\t\tEscape Failed! \n" +
                "Although you successfully made it to the escape pod, you did not gather enough " +
                "survival items to survive the trip. Although you are safe from the meteors, " +
                "you were unable to survive the journey back home.");

        // Activates and reacts to the activation start game button.
        Button startButton = findViewById(R.id.start_button);
        // Sets start button to be enabled by default.
        startButton.setEnabled(false);

        // Activates and reacts to the activation end game button.
        Button endGameButton = findViewById(R.id.end_game_button);
        // Sets end game button to be enabled by default.
        endGameButton.setEnabled(true);

        // Sets the login button to be disabled as long as the game has not been started.
        Button inventoryButton = findViewById(R.id.view_inventory_button);
        // Sets Inventory button to be disabled by default.
        inventoryButton.setEnabled(false);

        // Sets the collect item button to be disabled as long as the game has not been started.
        Button collectItemButton = findViewById(R.id.collect_item_button);
        // Sets Collect Item button to be disabled by default.
        collectItemButton.setEnabled(false);

        // Sets the north button to be disabled as long as the game has not been started.
        Button northButton = findViewById(R.id.north_button);
        // Sets north button to be disabled by default.
        northButton.setEnabled(false);

        // Sets the south button to be disabled as long as the game has not been started.
        Button southButton = findViewById(R.id.south_button);
        // Sets south button to be disabled by default.
        southButton.setEnabled(false);

        // Sets the east button to be disabled as long as the game has not been started.
        Button eastButton = findViewById(R.id.east_button);
        // Sets east button to be disabled by default.
        eastButton.setEnabled(false);

        // Sets the west button to be disabled as long as the game has not been started.
        Button westButton = findViewById(R.id.west_button);
        // Sets west button to be disabled by default.
        westButton.setEnabled(false);
    }

    public void timedDefeatScreen() {
        // Sets the game text to the game text field within the game play activity.
        TextView gameText = findViewById(R.id.game_text);
        gameText.setText("\t\t\t\t\t\t\t\t\t\tEscape Failed! \n" +
                "You ran out of time, the meteors made it before you were able to leave in the escape pod! ");

        // Activates and reacts to the activation start game button.
        Button startButton = findViewById(R.id.start_button);
        // Sets start button to be enabled by default.
        startButton.setEnabled(false);

        // Activates and reacts to the activation end game button.
        Button endGameButton = findViewById(R.id.end_game_button);
        // Sets end game button to be enabled by default.
        endGameButton.setEnabled(true);

        // Sets the login button to be disabled as long as the game has not been started.
        Button inventoryButton = findViewById(R.id.view_inventory_button);
        // Sets Inventory button to be disabled by default.
        inventoryButton.setEnabled(false);

        // Sets the collect item button to be disabled as long as the game has not been started.
        Button collectItemButton = findViewById(R.id.collect_item_button);
        // Sets Collect Item button to be disabled by default.
        collectItemButton.setEnabled(false);

        // Sets the north button to be disabled as long as the game has not been started.
        Button northButton = findViewById(R.id.north_button);
        // Sets north button to be disabled by default.
        northButton.setEnabled(false);

        // Sets the south button to be disabled as long as the game has not been started.
        Button southButton = findViewById(R.id.south_button);
        // Sets south button to be disabled by default.
        southButton.setEnabled(false);

        // Sets the east button to be disabled as long as the game has not been started.
        Button eastButton = findViewById(R.id.east_button);
        // Sets east button to be disabled by default.
        eastButton.setEnabled(false);

        // Sets the west button to be disabled as long as the game has not been started.
        Button westButton = findViewById(R.id.west_button);
        // Sets west button to be disabled by default.
        westButton.setEnabled(false);
    }

    /*
    ENHANCEMENT: Allows room randomization, while also ensuring the Observatory, Hallway, and
    Escape Pod rooms are always present within the games map. Guarantees six rooms are
    selected and each have items. This will allow for smooth gameplay but also randomization.

    Trade Off: Although this randomized map will make it difficult for players to gain a strong
    insight of the map layout it will allow for a better gameplay experience.

     */
    // Randomizes the room selection at game start, while ensuring specific rooms are always present.
    public void randomRoom() {
        // Optimization: I decided to manually remove the static rooms from the list initially to help
        // ensure consistent room encounters within the generated map. This helped ensure no doubles of a map were present
        // when adding the static rooms later in the algorithm.

        // Time Complexity: O(n) - Utilized for the number of rooms, or removing a room. O(1) when Utilizing
        // a hashmap which remains efficient and ensures time complexity remains constant.

        // Efficiency of Algorithmic Logic: By utilizing add and remove to the list I was able to determine
        // the exact map layout that was planned. By randomizing only the maps that were suppose to be randomized
        // helped ensure every time the game started required rooms would be accessible allowing the avoidance of
        // room checks after map layout was created.

        // Creates a List for all rooms within the rooms hashmap.
        List<String> allAvailableRooms = new ArrayList<>(rooms.keySet());

        // Removes the Observatory, Hallway, and Escape Pod located within the all available rooms list.
        // Time Complexity: O(n) Involves removing a room from a list.
        allAvailableRooms.remove("Observatory");
        // Time Complexity: O(n) Involves removing a room from a list.
        allAvailableRooms.remove("Hallway");
        // Time Complexity: O(n) Involves removing a room from a list.
        allAvailableRooms.remove("Escape Pod");

        // Shuffles the all available rooms list and adds rooms from that list until six rooms are selected.
        // Time Complexity: O(n) Shuffles the list to introduce randomness to the available rooms list.
        Collections.shuffle(allAvailableRooms);

        // List for six selected random rooms.
        // Time Complexity: O(1) - Utilizes sublist to select the number of rooms.
        List<String> selectedRandomRooms = allAvailableRooms.subList(0, 6);
        // List for all selected rooms.
        List<String> allSelectedRooms = new ArrayList<>();

        // Ensures the Observatory, Hallway, and Escape Pod are located within every game map.
        // Time Complexity: O(1) - Adding rooms to a the all selected rooms list.
        allSelectedRooms.add("Observatory");
        // Time Complexity: O(n) - Adds six rooms to the all selected rooms list.
        allSelectedRooms.addAll(selectedRandomRooms);
        // Time Complexity: O(1) - Adding rooms to a the all selected rooms list.
        allSelectedRooms.add("Hallway");
        // Time Complexity: O(1) - Adding rooms to a the all selected rooms list.
        allSelectedRooms.add("Escape Pod");

        // Creates a new hash map that will store the randomized rooms.
        // Time Complexity: O(1) - Since going through a hashmap remains constant.
        HashMap<String, HashMap<String, String>> randomRooms = new HashMap<>();
        for (String room : allSelectedRooms) {
            // Searches the rooms hashmap for the room names then brings over the rooms details hashmap.
            randomRooms.put(room, rooms.get(room));
        }
        // Ensures the rooms hash map copies the information from the random rooms hash map.
        rooms = randomRooms;
    }

    /*
    ENHANCEMENT: Allows for room connection randomization. The goal would be so the player will
    not always know which direction to move in.

    Trade Off: This will increase the difficulty of the game as the layout cannot be properly
    memorized. So although in the short term players may find it as a draw back for speed runs,
    in the long run this creates a healthier gameplay experience for players by introducing
    replay ability.
    */
    // Randomizes how each room connects via cardinal directions, while also ensuring randomized
    // room connections apply both ways.
    public void randomRoomConnection() {
        // Optimization: I decided to use a list of pairs of cardinal directions to ensure each current
        // room and next room would be connected uniquely while avoiding the potential of repeated directions
        // overwriting a previous room alignment. This helps ensure room connections is varied for the gameplay.

        // Time Complexity: O(n), n is the number of rooms being utilized in this case it would be 8 rooms in total.

        // Efficiency of Algorithmic Logic: By utilizing pairs of cardinal directions and looping not only
        // through rooms but also through the cardinal direction pairs it ensures each room has a unique connection,
        // each room is connected in the opposite direction, while also ensuring no error checks are needed in terms
        // of room connections as looping through rooms and connections ensures constant linear complexity which scales
        // with the number of rooms.

        // Creates a new list that will apply randomized connections to each of the random rooms.
        List<String> roomOrder = new ArrayList<>(rooms.keySet());

        // Creates a new list that will contain the possible cardinal directions that each room can have.
        // Time Complexity: O(n) - Number of potential cardinal direction pairs.
        List<String[]> directionPairs = Arrays.asList(
                new String[]{"North", "South"},
                new String[]{"East", "West"},
                new String[]{"South", "North"},
                new String[]{"West", "East"}
        );

        // Variable to go through the cardinal direction pairs list.
        int directionIndex = 0;
        // Ensures each current room connects to the previous room and the next room.
        for (int i = 0; i < roomOrder.size() - 1; i++) {
            // Represents the current room.
            String currentRoom = roomOrder.get(i);
            // Represents the next room.
            String nextRoom = roomOrder.get(i + 1);

            // Sets the current direction pair to the direction index.
            String[] currentDirectionPair = directionPairs.get(directionIndex);
            // Assigns the a cardinal direction to the North.
            String direction = currentDirectionPair[0];
            // Assigns a cardinal direction to the South.
            String oppositeDirection = currentDirectionPair[1];

            // Adds connection from the current room to the next room.
            // Time Complexity: O(1) - Takes constant time when adding the directional inputs to the hashmap.
            rooms.get(currentRoom).put(direction, nextRoom);
            // Adds connection from the next room back to the current room to ensure smooth travel.
            // Time Complexity: O(1) - Takes constant time when adding the directional inputs to the hashmap.
            rooms.get(nextRoom).put(oppositeDirection, currentRoom);

            // Ensures looping through the list to ensure rooms have different cardinal directions.
            // Time Complexity: O(1) - Takes constant time when adjusting the directions index when looping through the direction pairs list.
            directionIndex = (directionIndex + 1) % directionPairs.size();
        }
    }

    // Triggers both the random room creation and random room connections.
    public void roomSetup () {
        randomRoom();
        randomRoomConnection();
    }
}