/*
Author: Mark Irwin
Date: 9/24/2024
Version: 1.1

Description: Leaderboard Activity represents the leaderboard menu within the starship escape game.
This currently allows users to enter the leaderboard screen and return back to the main menu.

*/


package com.example.capstone_spaceship_escape_mark_irwin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class LeaderboardActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.leaderboard);

        Button returnMenuButton = findViewById(R.id.return_menu_button);
        returnMenuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Return to the Main Menu.
                Intent intent = new Intent(LeaderboardActivity.this, MainActivity.class);
                // Ensures that the main menu activity will always be closed when pressing the exit game button.
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });
    }
}